package Dietetian;

public class Training {

}
